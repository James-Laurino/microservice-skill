package com.example.demo;
enum Currencies {
  USD,
  INR,
  YEN
}